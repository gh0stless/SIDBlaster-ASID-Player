Welcome to the SIDBlaster ASID protocol player for MacOS.

First you have to install the FTDI D2XX drivers.

You need to set up a MIDI loop port in MacOS.

Plug in your SIDBlaster and then start ASID Player and select the MIDI loop port.

Safari does not support MIDI output, use the Firefox browser for example.

Now go to:
https://deepsid.chordian.net/
Select ASID (MIDI) as the player and then select the same MIDI port.
Play a tune...

---
ASIDPlayer was made by Andreas Schumm (gh0stless) 2024.
hardsid library for sidblaster by Stein Pedersen & Ken Händel
Thanks to Wilfred Bos for tips and tricks.


contact: info@crazy-midi.de
www.crazy-midi.de
